<?php

    function is_pjax(){ 
      return array_key_exists('HTTP_X_PJAX', $_SERVER) && $_SERVER['HTTP_X_PJAX']; 
    }
    
    if( is_pjax() ){
        
    }
    else{
        header("location:../");
        exit();
    }

?>

<?php

    if(isset($_POST['song_name'])){
        header("content-type:text/html;charset=utf-8"); 
        $song_name = $_POST['song_name'];
        //echo($song_name);
    }
    else{
        header("location:../");
        exit();
    }

?>

<?php

    class pc{
        function get_song_list($name){
            //header("content-type:text/html;charset=utf-8"); 
            header('Content-Type:application/json');
            $name = urlencode($name);
            $req = json_decode(file_get_contents("https://v1.itooi.cn/netease/search?keyword=$name&type=song&pageSize=100&page=0"),true);
            //echo($req['data']);
            $lst = $req['data']['songs'];
            return $lst;
        }
    }

?>

<?php
    
    $song_ctl = new pc;
    $song_list = $song_ctl -> get_song_list($song_name);

?>

<div class="mdui-table-fluid">
  <table class="mdui-table">
    <thead>
      <tr>
        <th>id</th>
        <th>歌名</th>
        <th>歌手</th>
        <th>
            操作
        </th>
      </tr>
    </thead>
    <tbody>
      <?php
      
          foreach($song_list as $song_item){
              $song_name = $song_item['name'];
              $song_id = $song_item['id'];
              $singer = $song_item['ar'];
              $song_singer = "";
              foreach($singer as $song_s){
                  $name_l = $song_s['name'];
                  $song_singer .= $name_l."/";
              }
              echo("<tr>");
              echo("<td>$song_id</td>");
              echo("<td>$song_name</td>");
              echo("<td>$song_singer</td>");
              echo ("
                      <td><button class='mdui-fab' onclick=\"play_m('$song_id')\">
              
                      <svg t=\"1583976910724\" class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path d=\"M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z\" p-id=\"2077\"></path></svg>
              
              </button></td>
              <audio src=\"https://music.163.com/song/media/outer/url?id=$song_id.mp3\" id=\"audio$song_id\" controls=\"controls\" loop=\"false\" hidden=\"true\">

    </audio>
            ");
              echo("</tr>");
          }
      
      ?>
    </tbody>
  </table>
</div>

<script>
    window.isplaying=false
    window.audioas = "";
    function autoPlay(song_id) {
        var myAuto = document.getElementById('audio'+song_id);
        myAuto.play();
    }
    function closePlay(song_id) {
        var myAuto = document.getElementById('audio'+song_id);
        myAuto.pause();
        myAuto.load();
    }
    function pausePlay(song_id) {
        var myAuto = document.getElementById('audio'+song_id);
        myAuto.pause();
        //myAuto.load();
    }
    function startPlay(song_id,song_past) {
        var myAuto = document.getElementById('audio'+song_id);
        var myAutop = document.getElementById('audio'+song_past);
        myAutop.load()
        myAuto.play();
        //myAuto.load();
    }
    window.song_now = ""
    function play_m(song_id){
        if(song_id !== window.song_now && window.song_now !== ""){
            startPlay(song_id,window.song_now)
            window.song_now = song_id
        }
        else{
            if(window.isplaying == false){
                window.isplaying = true
                window.song_now = song_id
                autoPlay(song_id)//播放
            }
            else{
                pausePlay(song_id);
                window.isplaying = false
            }
        }
    }
    
    
</script>