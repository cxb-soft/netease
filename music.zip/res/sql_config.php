<?php

    $db = mysqli_connect("localhost","exam","wabadmin1","exam");

?>