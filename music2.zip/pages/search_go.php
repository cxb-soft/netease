<?php

    function is_pjax(){ 
      return array_key_exists('HTTP_X_PJAX', $_SERVER) && $_SERVER['HTTP_X_PJAX']; 
    }
    
    if( is_pjax() ){
        
    }
    else{
        header("location:../");
        exit();
    }

?>

<?php
    function send_req($url,$pars){
            $ch = curl_init();
            //指定URL
            curl_setopt($ch, CURLOPT_URL, $url);
            //设定请求后返回结果
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            //声明使用POST方式来进行发送
            curl_setopt($ch, CURLOPT_POST, 1);
            //curl_setopt($curl, CURLOPT_USERAGENT, 'Chrome 42.0.2311.135');
            //发送什么数据呢
            curl_setopt($ch, CURLOPT_POSTFIELDS, $pars);
            //忽略证书
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            //忽略header头信息
            curl_setopt($ch, CURLOPT_HEADER, 0);
            //设置超时时间
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            //发送请求
            
            $output = curl_exec($ch);
            //关闭curl
            ;
            curl_close($ch);
            //file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=$chatid&text=不懂不懂");
            return $output;
        }
class netease{
        function get_song_lists($name){
            //header("content-type:text/html;charset=utf-8"); 
            
            header('Content-Type:application/json');
            $name = urlencode($name);
            //file_get_contents("https://api.telegram.org/bot1092137381:AAEqVtocp01TELZoUB8ayCasT9f26EDms6g/sendMessage?chat_id=-426558199&text=suc");
            $this -> result = $this -> curl_request("http://music.163.com/api/search/get/web?csrf_token=hlpretag=&hlposttag=&s=$name&type=1&offset=0&total=true&limit=100");
            
            $req = $this -> result;
            //echo($req['data']);
            $lst = $req['result'];
            //$test = $lst[0]['id'];
            //file_get_contents("https://api.telegram.org/bot1092137381:AAEqVtocp01TELZoUB8ayCasT9f26EDms6g/sendMessage?chat_id=-426558199&text=$test");
            return $lst;
        }
        function curl_request($url,$post = '',$cookie = '', $returnCookie = 0) {
          $ip_long = array(
            array('607649792', '608174079'), //36.56.0.0-36.63.255.255
            array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
            array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
            array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
            array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
            array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
            array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
            array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
            array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
            array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
          );
          $rand_key = mt_rand(0, 9);
          $ip = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
          //随机ip
          $header = array(
            "CLIENT-IP: $ip",
            "X-FORWARDED-FOR: $ip",
            "X-Real-IP: $ip"
          );
          $curl = curl_init();
          curl_setopt($curl, CURLOPT_URL, $url);
          curl_setopt($curl, CURLOPT_USERAGENT, 'User-Agent, Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11');
          curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
          curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
          curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
          curl_setopt($curl, CURLOPT_REFERER, "https://music.163.com");
          if ($post) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
          }
          if ($cookie) {
            curl_setopt($curl, CURLOPT_COOKIE, $cookie);
          }
          curl_setopt($curl, CURLOPT_HEADER, $returnCookie);
          curl_setopt($curl, CURLOPT_TIMEOUT, 10);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
          $data = curl_exec($curl);
          if (curl_errno($curl)) {
            return curl_error($curl);
          }
          curl_close($curl);
          if ($returnCookie) {
            list($header, $body) = explode("\r\n\r\n", $data, 2);
            preg_match_all("/Set\-Cookie:([^;]*);/", $header, $matches);
            $info['cookie'] = substr($matches[1][0], 1);
            $info['content'] = $body;
            return json_decode($info,true);
          } else {
            return json_decode($data,true);
          }
        }
    
    	function curl_request2($url,$post = '',$cookie = '', $returnCookie = 0) {
          $ip_long = array(
            array('607649792', '608174079'), //36.56.0.0-36.63.255.255
            array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
            array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
            array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
            array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
            array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
            array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
            array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
            array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
            array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
          );
          $rand_key = mt_rand(0, 9);
          $ip = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
          //随机ip
          $header = array(
            "CLIENT-IP: $ip",
            "X-FORWARDED-FOR: $ip",
            "X-Real-IP: $ip"
          );
          $curl = curl_init();
          curl_setopt($curl, CURLOPT_URL, $url);
          curl_setopt($curl, CURLOPT_USERAGENT, 'User-Agent, Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11');
          curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
          curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
          curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
          curl_setopt($curl, CURLOPT_REFERER, "https://music.163.com");
          if ($post) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
          }
          if ($cookie) {
            curl_setopt($curl, CURLOPT_COOKIE, $cookie);
          }
          curl_setopt($curl, CURLOPT_HEADER, $returnCookie);
          curl_setopt($curl, CURLOPT_TIMEOUT, 10);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
          $data = curl_exec($curl);
          if (curl_errno($curl)) {
            return curl_error($curl);
          }
          curl_close($curl);
          if ($returnCookie) {
            list($header, $body) = explode("\r\n\r\n", $data, 2);
            preg_match_all("/Set\-Cookie:([^;]*);/", $header, $matches);
            $info['cookie'] = substr($matches[1][0], 1);
            $info['content'] = $body;
            return $info;
          } else {
            return $data;
          }
    	}
    }


    if(isset($_POST['song_name'])){
        header("content-type:text/html;charset=utf-8"); 
        $song_name = $_POST['song_name'];
        //echo($song_name);
    }
    else{
        header("location:../");
        exit();
    }

?>

<?php

    class pc{
        function get_song_list($name){
            //header("content-type:text/html;charset=utf-8"); 
            $netease = new netease;
            header('Content-Type:application/json');
            //$name = urlencode($name);
            $req = $netease -> get_song_lists($name);
            //echo($req['data']);
            
            $lst = $req['songs'];
            return $lst;
        }
    }

?>

<?php
    
    $song_ctl = new pc;
    $song_list = $song_ctl -> get_song_list($song_name);

?>

<div class="mdui-table-fluid">
  <table class="mdui-table">
    <thead>
      <tr>
        <th>id</th>
        <th>歌名</th>
        <th>歌手</th>
        <th>
            操作
        </th>
      </tr>
    </thead>
    <tbody>
      <?php
      
          foreach($song_list as $song_item){
              $song_name = $song_item['name'];
              $song_id = $song_item['id'];
              $singer = $song_item['artists'];
              $song_singer = "";
              foreach($singer as $song_s){
                  $name_l = $song_s['name'];
                  $song_singer .= $name_l."/";
              }
              echo("<tr>");
              echo("<td>$song_id</td>");
              echo("<td>$song_name</td>");
              echo("<td>$song_singer</td>");
              echo ("
                      <td><button id='$song_id,b' class='mdui-fab' name='playbut' onclick=\"play_m('$song_id')\">
                      
                      <svg t=\"1583976910724\"  class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path id='$song_id,a' d=\"M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z\" p-id=\"2077\"></path></svg>
              
              </button></td>
              <audio src=\"https://music.163.com/song/media/outer/url?id=$song_id.mp3\" id=\"audio$song_id\" controls=\"controls\" loop=\"false\" hidden=\"true\">

    </audio>
    
            ");
              echo("</tr>");
          }
      
      ?>
      
    </tbody>
  </table>
</div>

<script>
    window.isplaying=false
    window.audioas = "";
    function autoPlay(song_id) {
        document.getElementsByName("playbut").innerHTML = "<svg t=\"1583976910724\"  class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path id='$song_id,a' d=\"M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z\" p-id=\"2077\"></path></svg>"
        var myAuto = document.getElementById('audio'+song_id);
        myAuto.play();
        document.getElementById(song_id+",b").innerHTML = "<svg t=\"1593942149110\" class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path d=\"M280 99m40 0l0 0q40 0 40 40l0 746q0 40-40 40l0 0q-40 0-40-40l0-746q0-40 40-40Z\" fill=\"#1296db\" p-id=\"2077\"></path><path d=\"M663 99m40 0l0 0q40 0 40 40l0 746q0 40-40 40l0 0q-40 0-40-40l0-746q0-40 40-40Z\" fill=\"#1296db\" p-id=\"2078\"></path></svg>"
    }
    function closePlay(song_id) {
        var myAuto = document.getElementById('audio'+song_id);
        myAuto.pause();
        myAuto.load();
        document.getElementsByClassName("playbut").innerHTML = "<svg t=\"1583976910724\"  class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path id='$song_id,a' d=\"M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z\" p-id=\"2077\"></path></svg>"
    }
    function pausePlay(song_id) {
        var myAuto = document.getElementById('audio'+song_id);
        myAuto.pause();
        document.getElementById(song_id+",b").innerHTML = "<svg t=\"1583976910724\"  class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path id='$song_id,a' d=\"M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z\" p-id=\"2077\"></path></svg>"
        //myAuto.load();
    }
    function startPlay(song_id,song_past) {
        document.getElementById(song_past+",b").innerHTML = "<svg t=\"1583976910724\"  class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path id='$song_id,a' d=\"M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z\" p-id=\"2077\"></path></svg>"
        var myAuto = document.getElementById('audio'+song_id);
        var myAutop = document.getElementById('audio'+song_past);
        document.getElementById(song_id+",b").innerHTML = "<svg t=\"1593942149110\" class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2076\" width=\"32\" height=\"32\"><path d=\"M280 99m40 0l0 0q40 0 40 40l0 746q0 40-40 40l0 0q-40 0-40-40l0-746q0-40 40-40Z\" fill=\"#1296db\" p-id=\"2077\"></path><path d=\"M663 99m40 0l0 0q40 0 40 40l0 746q0 40-40 40l0 0q-40 0-40-40l0-746q0-40 40-40Z\" fill=\"#1296db\" p-id=\"2078\"></path></svg>"
        myAutop.load()
        myAuto.play();
        //myAuto.load();
    }
    window.song_now = ""
    function play_m(song_id){
        if(song_id !== window.song_now && window.song_now !== ""){
            startPlay(song_id,window.song_now)
            window.song_now = song_id
        }
        else{
            if(window.isplaying == false){
                window.isplaying = true
                window.song_now = song_id
                autoPlay(song_id)//播放
            }
            else{
                pausePlay(song_id);
                window.isplaying = false
            }
        }
    }
    
    
</script>