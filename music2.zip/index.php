<?php

    require_once("config/config.php");
    
?>

<html>
    <head>
        <title><?php echo($site_name) ?></title>
        
        <link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.3/css/mdui.min.css">
        <link rel="stylesheet" href="/res/animate.css">
        <link rel="stylesheet" href="//service.bsot.cn/cdn/nprogress/nprogress.css">
        <script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.3/js/mdui.min.js" data-pjax=""></script>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="/favicon.ico">
        <script src="//service.bsot.cn/cdn/jquery/dist/jquery.min.js" data-pjax=""></script>
        <script src="//service.bsot.cn/cdn/jquery-pjax/jquery.pjax.js" data-pjax=""></script>
        <script src="//service.bsot.cn/cdn/nprogress/nprogress.js" data-pjax=""></script>
        <script>
            $(document).on('pjax:start', function() { NProgress.start(); });
            $(document).on('pjax:end',   function() { NProgress.done();  });
        </script>
    </head>
    <body background="/res/bj.png" class="mdui-drawer-body-left mdui-appbar-with-toolbar mdui-loaded" id="pjax-body">
        <header class="mdui-appbar mdui-appbar-fixed">
            <style>
                a {
                  text-decoration:none
                }
                a:hover {
                  text-decoration:none
                }
                .beauty-mdui{
                    padding-right: 5%;
                    padding-left: 5%;
                }
              </style>
            
            <div class="mdui-toolbar mdui-color-theme">
                <span class="mdui-btn mdui-btn-icon mdui-ripple" mdui-drawer="{target: '#main-drawer'}">
                    <i class="mdui-icon material-icons">menu</i>
                </span>
                <a href="" class="mdui-typo-title"><?php echo($site_name) ?></a>
            </div>
        </header>
        <div class="mdui-drawer" id="main-drawer">
            <div class="mdui-list" mdui-collapse="{accordion: true}" style="margin-bottom: 68px;">
                <div class="mdui-list">
                    <a href="javascript:void(0)" onclick="go_index()" class="mdui-list-item">
                        <svg t="1583762240826" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2088" width="32" height="32"><path d="M618.775862 854.723665c0-35.763528 0.112564-83.739193-0.031722-117.392664-0.127913-27.329439-5.867638-33.224706-32.721239-33.341363-39.933501-0.163729-79.865979-0.147356-119.79948-0.007163-27.369348 0.095167-32.573883 4.948709-33.008788 33.016974-0.528026 33.605376-0.127913 81.556481-0.127913 116.696816-7.55507 0.871857-12.839423 1.987261-18.131963 2.010797-36.19127 0.152473-72.387657 0.452301-108.574834-0.023536-42.947138-0.563842-53.088102-11.304464-52.78418-53.383838 0.268106-38.038338-0.327458-199.909006 0.715291-237.926878 0.211824-7.574512 4.185322-17.064654 9.6815-22.177092 72.167646-67.110467 144.806014-133.713374 217.58048-200.167902 29.03222-26.5067 63.293535-26.821879 92.369757-0.039909 72.954569 67.186192 145.493675 134.823662 217.712487 202.793706 5.080715 4.780887 8.618285 13.719466 8.765641 20.805862 0.188288 9.190313 0.98749 172.98889 0.288572 243.611344-0.264013 26.41358-13.287631 44.094264-37.71088 45.0091C715.775057 855.975169 668.443052 854.723665 618.775862 854.723665L618.775862 854.723665z" p-id="2089"></path><path d="M519.040347 134.911666c35.567054-0.071631 54.090942 11.728112 70.727855 27.841092 64.0999 62.062498 128.316457 124.020618 192.453197 186.046277 29.604248 28.632107 59.135842 57.345056 88.679715 86.041632 3.130294 3.045359 6.240121 6.135744 9.129938 9.4093 16.441461 18.62315 18.651802 38.610366 6.087649 54.259788-13.246699 16.492626-39.792285 20.35356-59.555397 8.233522-5.252631-3.225461-9.992585-7.438413-14.502295-11.695367-73.009827-69.01791-146.012492-138.03889-218.874963-207.215412-53.939493-51.209312-74.593905-51.625798-129.080867-1.003863-72.682369 67.530023-144.785547 135.688355-218.039945 202.591091-10.333346 9.441023-25.131377 15.928784-38.941917 19.134803-18.127869 4.204765-33.097816-5.004991-41.544185-21.713534-8.482185-16.776082-5.108345-32.985252 6.852058-46.944172 6.863315-8.014534 14.957667-15.001669 22.695908-22.236444 89.803305-83.959204 179.734524-167.762865 269.385357-251.885797C483.315704 148.134829 503.802294 135.14805 519.040347 134.911666L519.040347 134.911666z" p-id="2090"></path></svg>
                        &emsp;首页
                    </a>
                </div>
            </div>
        </div>
        <div class="beauty-mdui" id="pjax-change"></div>
        <script>
            $.pjax({
               url : "/pages/index.php",
               container : "#pjax-change",
               timeout : 10000
            })
            function go_index(){
                $.pjax({
                   url : "/pages/index.php",
                   container : "#pjax-change",
                   timeout : 10000
                })
            }
            
        </script>
    
    </body>
</html>